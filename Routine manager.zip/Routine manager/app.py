from flask import Flask
from datetime import date

today = str(date.today())

from flask import Flask, render_template, request, url_for, redirect
from pymongo import MongoClient

# ...

app = Flask(__name__)

client = MongoClient('localhost', 27017)

db = client.mydb
todos = db.professions
newdb= db.routine

messages=[]
i=0
@app.route('/', methods=('GET', 'POST'))
def index():
    if request.method=='POST':
        content = request.form['profession']
        # degree = request.form['degree']
        # todos.insert_one({'content': content, 'degree': degree})
        print(content,'hjklopiu')
        messages.append({'profession': content})
        print(messages)
        return redirect(url_for('front',messages=messages))
    # all_todos = todos.find({'content':'hello'})
    # print(todos.find({'content':'hello'}).value)
    return render_template('mech.html')


@app.route('/front',methods=['GET', 'POST'])
def front():
#    print(messages[0]['profession'])
   all_todos = todos.find({'name':messages[0]['profession']})
   l=[]
   for doc in all_todos:
    l.append(doc)
   print(messages,2)
   print(l,'here2')
#    print(i)
   whole = newdb.find()
   l1=[]
   for doc1 in whole:
    l1.append(doc1)
   print(l1)
   l2=[]
   sleep=0
   rest=0
   workout=0
   others=0
   job=0
   len1=len(l1)
   for i in l1:
    sleep+=i['sleep']
    rest+=i['rest']
    workout+=i['workout']
    job+=i['job']
    others+=i['others']
   if len1!=0:
    sleep//=len1
    rest//=len1
    workout//=len1
    others//=len1
    job//=len1
    if (sleep+rest+workout+others+job)!=24:
        print(sleep,sleep+rest+workout+others+job)
        sleep=sleep+(24-(sleep+rest+workout+others+job))
   l2=[{'sleep':sleep,'rest':rest,'others':others,'job':job,'workout':workout}]
   l.append({'sleep':sleep,'rest':rest,'others':others,'job':job,'workout':workout})
   print(l,'here1')
   return render_template('front.html',l=l)

@app.route('/insert', methods=('GET', 'POST'))
def insert():
    if request.method=='POST':
        d={'date':today,'sleep':0,'rest':0,'workout':0,'others':0,'job':0}
        r=['1201','0102','0203','0304','0405','0506','0607','0708','0809','0910','1011','1112',
        '1213','1314','1415','1516','1617','1718','1819','1920','2021','2122','2223','2324']
        for i in r:
            m=request.form[i]
            d[m]+=1
        print(d)
        # degree = request.form['degree']
        newdb.insert_one(d)
        # print(content,'hjklopiu')
        # messages.append({'profession': content})
        # print(messages)
        return redirect(url_for('front',messages=messages))

if __name__ == '__main__':
   app.run(debug = True)






